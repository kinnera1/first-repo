import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Player } from './Player';

@Injectable({
  providedIn: 'root'
})
export class CricketService {
  private baseUrl="http://localhost:8080/CricketApp";
 
  constructor(private http: HttpClient) { }
  getPlayers(){ 
    return this.http.get(`${this.baseUrl}/players`);
  }
  getPlayer(id:number){ 
    return this.http.get(`${this.baseUrl}/players/${id}`);
  }
  addPlayer(player:Player){ 
    return this.http.post(`${this.baseUrl}/players`,player);
  }
  getCategories(){ 
    return this.http.get(`${this.baseUrl}/categories`);
  }
  updatePlayer(player:Player){ 
    return this.http.put(`${this.baseUrl}/players`,player);
  }
  deletePlayer(id:number){
    return this.http.delete(`${this.baseUrl}/players/${id}`);
  }
  getPlayerStatistics(pid:number){
    return this.http.get(`https://cricapi.com/api/playerStats?apikey=E86ihzcfLPgkBzWUsfKH3uDKg0j2&pid=${pid}`);
    
  }
  getPlayerIdFromRest(name:string){
    return this.http.get(`https://cricapi.com/api/playerFinder?apikey=E86ihzcfLPgkBzWUsfKH3uDKg0j2&name=${name}`);
    
  }
  getWorldcupMatches(){
    return this.http.get(`https://cricapi.com/api/matchCalendar?apikey=E86ihzcfLPgkBzWUsfKH3uDKg0j2`);
    
  }
  
}
