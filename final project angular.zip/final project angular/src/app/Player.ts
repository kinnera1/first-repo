export class Player{
    id: number;
    category: string;
    name: string;
    image: string;
    country: string;
    createdAt: Date;
    updatedAt: Date;
    major_teams: string;
}