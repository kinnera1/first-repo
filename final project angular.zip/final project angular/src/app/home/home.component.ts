import { Component, OnInit } from '@angular/core';
import { CricketService } from '../cricket.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  restMatches:any;
  constructor(private cricketService: CricketService) { }

  ngOnInit() {
    this.getWorldcupMatches();
  }
  getWorldcupMatches(){
    this.cricketService.getWorldcupMatches().subscribe((data)=>{
      this.restMatches=data["data"];
      console.log(this.restMatches);
    },err=>{
      alert("Failed to add player. Please try again!!!");
    });
  }

}
