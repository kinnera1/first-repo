export class Admin{
    name: string;
    password: string;
}