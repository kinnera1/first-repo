import { Component, OnInit } from '@angular/core';
import { Admin } from '../admin';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  isAdmin:boolean=false;
  admin:Admin={
    name:'',
    password:''
    
  };
  constructor() { }

  ngOnInit() {
  }
  adminLogin(){
    console.log(this.admin.name+"   "+this.admin.password)
    if(this.admin.name=='kinnera' && this.admin.password=='kinnu@30'){
      this.isAdmin=true;
    }else{
      alert("Username/Password is incorrect")
    }
  }
  logoutClick(){
    var val=confirm("Do you want to logout?");
    if(val==true){
    this.isAdmin=false;
    }
    console.log(this.isAdmin)
  }

}
