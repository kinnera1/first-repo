import { Component, OnInit } from '@angular/core';
import { Player } from '../Player';
import { CricketService } from '../cricket.service';

@Component({
  selector: 'app-delete-player',
  templateUrl: './delete-player.component.html',
  styleUrls: ['./delete-player.component.css']
})
export class DeletePlayerComponent implements OnInit {

  players:Player[]=[];
  selectedPlayer: Player;
  constructor(private cricketService: CricketService) { }

  ngOnInit() {
    this.getPlayers();
  }
  getPlayers(){
    this.cricketService.getPlayers().subscribe((data:any)=>{
      this.players=data;
      //this.pages=new Array(data["totalPages"]);
    },err=>{
      console.log(err)
    });
  }
  onSelect(player: Player): void {
    this.selectedPlayer = player;
  }
  deletePlayer(id:number){
    this.cricketService.deletePlayer(id).subscribe(()=>{
      alert("player deleted successfully");
      //location.reload();
      this.getPlayers();
    },err=>{
      //console.log(err)
    });
    
  }
}
