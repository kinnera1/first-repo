import { Component, OnInit } from '@angular/core';
import { CricketService } from '../cricket.service';
import { Player } from '../Player';
import {ActivatedRoute} from "@angular/router";

@Component({
  selector: 'app-view-player',
  templateUrl: './view-player.component.html',
  styleUrls: ['./view-player.component.css']
})
export class ViewPlayerComponent implements OnInit {
  player:Player={
    id: 0,
    name:'',
    category: '',
    country: '',
    image: '',
    createdAt: null,
    updatedAt: null,
    major_teams:''
  };
  playerAvailable:boolean=false;
  id:number;
  profile:string;
  restPid:number;
  restName:string='';
  restAge:string='';
  restBattingOdis:any;
  restBowlingOdis:any;
  constructor(private cricketService: CricketService,private route: ActivatedRoute) { 
    //this.route.params.subscribe( params => alert(params) );
  }

  ngOnInit() {
    this.route.paramMap.subscribe(params => {
      this.id=this.route.snapshot.params.id
    });
    this.getPlayer();
    
  }
  getPlayer(){
    this.cricketService.getPlayer(this.id).subscribe((data:any)=>{
      this.player=data;
      //this.restName=this.player.name;
      console.log(this.player);
      this.getPlayerIdFromRest(this.player.name);
    },err=>{
      console.log(err)
    });
  }
  getPlayerStatistics(pid:number){
    this.cricketService.getPlayerStatistics(this.restPid).subscribe((data)=>{
      this.profile=data['profile'];
      this.restAge=data['currentAge'];
      this.restBattingOdis=data['data']["batting"];
      this.restBowlingOdis=data['data']["bowling"];
      console.log(this.profile);
    },err=>{
      console.log(err)
    });
  }
  getPlayerIdFromRest(name:string){
    this.cricketService.getPlayerIdFromRest(this.player.name).subscribe((data)=>{
      if(this.restPid!==null){
      this.restPid=data["data"][0]["pid"];
      console.log(this.restPid);
      
        this.playerAvailable=true;
      this.getPlayerStatistics(this.restPid);}
    },err=>{
      console.log(err)
    });

  }
  getKeys(obj){
    return Object.keys(obj)
  }
}
