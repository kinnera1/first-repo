import { Component, OnInit } from '@angular/core';
import { CricketService } from '../cricket.service';
import { Player } from '../Player';

@Component({
  selector: 'app-view-players',
  templateUrl: './view-players.component.html',
  styleUrls: ['./view-players.component.css']
})
export class ViewPlayersComponent implements OnInit {
  players:Player[]=[];
  selectedPlayer: Player;
  constructor(private cricketService: CricketService) { }

  ngOnInit() {
    this.getPlayers();
  }
  getPlayers(){
    this.cricketService.getPlayers().subscribe((data:any)=>{
      this.players=data;
      //this.pages=new Array(data["totalPages"]);
    },err=>{
      console.log(err)
    });
  }
  onSelect(player: Player): void {
    this.selectedPlayer = player;
  }

}
