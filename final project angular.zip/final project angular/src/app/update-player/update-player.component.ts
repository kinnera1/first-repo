import { Component, OnInit } from '@angular/core';
import { CricketService } from '../cricket.service';
import { ActivatedRoute } from '@angular/router';
import { Player } from '../Player';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-update-player',
  templateUrl: './update-player.component.html',
  styleUrls: ['./update-player.component.css']
})
export class UpdatePlayerComponent implements OnInit {
  id:number;
  players: Player[]=[];
  player:Player={
    id: 0,
    name:'',
    category: '',
    country: '',
    image: '',
    createdAt: null,
    updatedAt: null,
    major_teams:''
  };
  editPlayer:boolean=false;
  selectForm: FormGroup;
  angForm: FormGroup;
  constructor(private cricketService: CricketService,private route: ActivatedRoute,private fb:FormBuilder) { 
    //this.route.params.subscribe( params => alert(params) );
    this.createForm();
    this.createFormEdit();
  }

  ngOnInit() {
    this.getPlayers();
  }
  onChange(value:any){
    this.player.id=value;
    this.editPlayer=false;
    this.getPlayer();
      console.log(this.player)
  }
  createFormEdit() {
    this.angForm = this.fb.group({
       name: ['', Validators.required ],
       country: ['', Validators.required ],
       image: ['', Validators.required ],
       category: ['', Validators.required ],
       major_teams: ['', Validators.required ]
    });
  }

  createForm() {
    this.selectForm = this.fb.group({
       id: ['', Validators.required ]
    });
  }
  getPlayers(){
    this.cricketService.getPlayers().subscribe((data:any)=>{
      this.players=data;
      //this.pages=new Array(data["totalPages"]);
    },err=>{
      console.log(err)
    });
  }
  getPlayer(){
    this.cricketService.getPlayer(this.player.id).subscribe((data:any)=>{
      this.player=data;
      //console.log(this.id);
    },err=>{
      console.log(err)
    });
  }
  updateStatus(){
    this.editPlayer=true;
  }
  updatePlayer(){
    this.cricketService.updatePlayer(this.player).subscribe(()=>{
      alert("player updated successfully");
    },err=>{
      console.log(err)
    });
  }
}
