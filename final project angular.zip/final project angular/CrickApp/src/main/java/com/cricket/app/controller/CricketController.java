package com.cricket.app.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cricket.app.model.Category;
import com.cricket.app.model.Player;
import com.cricket.app.service.CategoryService;
//import com.cricket.app.service.PlayerService;
import com.cricket.app.service.PlayerServiceImpl;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class CricketController {
	@Autowired
	PlayerServiceImpl playerServiceImpl;
	
	@Autowired
	CategoryService categoryService;
	
	@GetMapping("/players")
	public List<Player> getPlayersList(){
		//List<Player> list=(List<Player>)playerServiceImpl.getPlayers(page);
		System.out.println(playerServiceImpl.getPlayers());
		return playerServiceImpl.getPlayers();
	}
	@GetMapping("/players/{id}")
	public Optional<Player> getPlayer(@PathVariable("id") int id){
		//List<Player> list=(List<Player>)playerServiceImpl.getPlayers(page);
		System.out.println(playerServiceImpl.getPlayers());
		return playerServiceImpl.getPlayer(id);
	}
	
	@PostMapping("/players")
	public void addPlayer(@RequestBody Player player){
		playerServiceImpl.addPlayer(player);
		//System.out.println(list);
		//return "Player added sucessfully";
	}
	
	@PostMapping("/Players")
	public String addPlayersList(){
		playerServiceImpl.addPlayers();
		return  "success";
	}
	
	@PutMapping("/players")
	public void UpdatePlayer(@RequestBody Player player){
		playerServiceImpl.updatePlayer(player);
	}
	
	@DeleteMapping("/players/{id}")
	public void deletePlayer(@PathVariable("id") int id){
		playerServiceImpl.deletePlayer(id);
	}
	@GetMapping("/categories")
	public List<Category> getCategories(){
		System.out.println("kinnera");
		return categoryService.getCategories();
	}

}
