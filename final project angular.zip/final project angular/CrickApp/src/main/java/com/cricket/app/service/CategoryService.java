package com.cricket.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cricket.app.model.Category;
import com.cricket.app.repository.CategoryRepository;

@Service
public class CategoryService {
	
@Autowired
CategoryRepository categoryRepository;

public List<Category> getCategories() {
	return categoryRepository.findAll();
}
}
