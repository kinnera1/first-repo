package com.cricket.app.repository;

import java.awt.print.Pageable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cricket.app.model.Player;
@Repository
public interface PlayerRepository extends JpaRepository<Player,Integer>{
	//public List<Player> findAll(Pageable pageable);

}
