package com.cricket.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import com.cricket.app.model.Player;
import com.cricket.app.repository.PlayerRepository;
@Service
public class PlayerServiceImpl implements PlayerService {
	@Autowired
	PlayerRepository playerRepository;

	@SuppressWarnings("deprecation")
	@Override
	public List<Player> getPlayers() {
		// TODO Auto-generated method stub
		
		return playerRepository.findAll();
	}

	@Override
	public String addPlayers() {
		// TODO Auto-generated method stub
		Player p1=new Player();
		p1.setCategory("Batsman");
		p1.setCountry("India");
		p1.setName("Kedar Mahadav Jadhav");
		p1.setImage("https://xmlns.cricketnext.com/cktnxt/scorecard/crk_player_images/players/128X128/4532.png");
		playerRepository.save(p1);
		return "added";
	}

	public void addPlayer(Player player) {
		// TODO Auto-generated method stub
		playerRepository.save(player);
		
	}

	@Override
	public Optional<Player> getPlayer(int id) {
		
		return playerRepository.findById(id);
	}

	@Override
	public void updatePlayer(Player player) {
		playerRepository.save(player);
		
	}

	@Override
	public void deletePlayer(int id) {
		// TODO Auto-generated method stub
		playerRepository.deleteById(id);
	}

}
