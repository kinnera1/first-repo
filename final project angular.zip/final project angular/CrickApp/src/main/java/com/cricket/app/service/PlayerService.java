package com.cricket.app.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;

import com.cricket.app.model.Player;

public interface PlayerService {
	public List<Player> getPlayers();
	public Optional<Player> getPlayer(int id);
	public String addPlayers();
	public void updatePlayer(Player player);
	public void deletePlayer(int id);
}
