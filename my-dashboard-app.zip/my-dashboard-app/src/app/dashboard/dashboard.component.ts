import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { DashboardService } from '../dashboard.service';
import { Block } from '../block.model';
import { LogService } from '../shared/log.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  @ViewChild('status',{static:false}) status:ElementRef;
   blocks:Block[]=[];
  kpi='kpiList';
  kpiData='kipiData';
  objectKeys = Object.keys;
  constructor(private dashboardService:DashboardService,
              private logService: LogService) { }

  ngOnInit() {
    this.logService.info("ngOnInIt - start");
    this.get_blocksData();
    this.logService.info("ngOnInIt - end");
  }
  get_blocksData(){
    this.dashboardService.get_blocks().subscribe((data:any[])=>{
      this.blocks=data;
      this.logService.info("Got Blocks Data");
      //console.log(Object.keys(this.blocks));
      //this.keys=Object.keys(this.blocks[0]);
      //this.keys1=Object.keys(data[0]["BLK1"]);
      //console.log(this.keys);
    },err=>{
      //console.log(err);
      this.logService.error(err);
    }
    )
    //console.log(this.status)
}
getKpiList(key){
  //console.log(key['kpiList']);
  return key['kpiList'];
}
getColor(key) {
  switch (key.status) {
    case 'Online':
      return '#00cc00';
    case 'Offline':
      return 'red';
  }
}
getWidth(arr1) {
  //console.log(arr1);
  var len=arr1.length;
  switch (len) {
    case 2:
      return 50;
    case 1:
      return 100;
  }
}
getBorder(j,arr2){
  var len=arr2.length;
  if(len==2 && j==1){
    return"none";
  }
}

}
