import { Injectable } from '@angular/core';
      
import { LogPublisher } from "./log-publisher";
import { LogConsole } from './log-console'
import { LogDataBase } from './log-db';
import { DashboardService } from '../dashboard.service';
      
@Injectable({
    providedIn: 'root'
})
export class LogPublishersService {
  constructor(private dashBoardService:DashboardService) {
    // Build publishers arrays
    this.buildPublishers();
  }
      
  // Public properties
  publishers: LogPublisher[] = [];
      
  // Build publishers array
  buildPublishers(): void {
    // Create instance of LogConsole Class
    this.publishers.push(new LogConsole());
    this.publishers.push(new LogDataBase(this.dashBoardService));
  }
}
