import { Observable } from 'rxjs';

import { LogPublisher } from './log-publisher';
import { LogEntry } from './log-entry';


export class LogConsole extends LogPublisher {
    log(entry: LogEntry): Observable<boolean> {
      // Log to console
      console.log(entry.buildLogString());
      return new Observable<boolean>(
          next =>{ true}
        );
    }
    clear(): Observable<boolean> {
      console.clear();
      return  new Observable<boolean>(
        next =>{ true}
        );
    }
  }