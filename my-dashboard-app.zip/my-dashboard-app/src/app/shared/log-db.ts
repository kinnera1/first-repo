import { Observable } from 'rxjs';

import { LogPublisher } from './log-publisher';
import { LogEntry } from './log-entry';
import { DashboardService } from '../dashboard.service';


export class LogDataBase extends LogPublisher {

    constructor(private dashboardService:DashboardService){
      super();
    }
    log(entry: LogEntry): Observable<boolean> {
      // Log to console
      //console.log(entry);


      this.dashboardService.post_error(entry.level,entry.message).subscribe();
      return new Observable<boolean>(
          next =>{ true}
        );
    }
    clear(): Observable<boolean> {
      console.clear();
      return  new Observable<boolean>(
        next =>{ true}
        );
    }
  }