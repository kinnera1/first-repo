import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  baseUrl:string = "http://localhost:8080/poc";

    constructor(private httpClient : HttpClient) {}

    get_blocks(){
        return this.httpClient.get(this.baseUrl+"/blocks", {
          headers: new HttpHeaders({'username':'kinnera', 'password':'password'})
        });
    }

    post_error(errorType: number, errorMessage:string){
      //console.log(error)
      return this.httpClient.post(this.baseUrl+"/errors",errorMessage,{
        headers: new HttpHeaders({'errorType':errorType.toString()})
      });
  }
    
    }