import { Component, OnInit, Output,EventEmitter, OnDestroy } from '@angular/core';
import { DataStorageService } from '../shared/data-storage.service';
import { AuthService } from '../auth/auth.service';
import { Subscription } from 'rxjs';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnDestroy {

  userSubscribe: Subscription;
  isAuthencated= false;
  constructor(private dataStrorageService:DataStorageService,
              private authService: AuthService) { }
  

  ngOnInit() {
    this.userSubscribe=this.authService.user.subscribe(user=>{
      this.isAuthencated= !!user;
    });
  }
  saveData(){
    this.dataStrorageService.storeRecipes();
  }
  fetchData(){
    this.dataStrorageService.fetchRecipes().subscribe();
  }

  onLogout(){
    this.authService.logOut();
  }
  ngOnDestroy(){
    this.userSubscribe.unsubscribe();
  }
}
