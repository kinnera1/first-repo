package com.poc.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.poc.model.JsonDataModel;
import com.poc.model.JsonKpiDataModel;
import com.poc.model.JsonKpiDate;
import com.poc.model.JsonKpiModel;
import com.poc.repository.JsoKpiDataRepository;
//import com.poc.repository.BlockRepository;
import com.poc.repository.JsonDatRepository;
import com.poc.repository.JsonKpiRepository;

@Service
@Transactional
public class BlockServiceImpl implements BlockService {

	
	@Autowired
	private JsonDatRepository jsonDatRepository;
	
	@Autowired
	private JsonKpiRepository jsonKpiRepository;

	@Autowired
	private JsoKpiDataRepository jsoKpiDataRepository ;
	
	public List<JsonDataModel> jsonData() {
		//System.out.println(jsonDatRepository.getBlocks());
		List<JsonDataModel> jsonDataModels=jsonDatRepository.findAll();
		//System.out.println(jsonDataModels);
		List<JsonKpiModel> jsonKpiModels=jsonKpiRepository.findAll();

		List<JsonKpiDataModel> jsonKpiDataModels=jsoKpiDataRepository.findAll();
		//System.out.println(jsonKpiModels);
		//System.out.println(jsonKpiDataModels);
		jsonDataModels.forEach(block -> {
			jsonKpiModels.forEach(kpi ->{
				jsonKpiDataModels.forEach(kpiData ->{
					if(block.getId()==kpiData.getJsonDataModel().getId() && 
							kpi.getId()==kpiData.getJsonKpiModel().getId()) {
						JsonKpiDate jsonKpiDate=new JsonKpiDate();
						jsonKpiDate.setId(kpiData.getId());
						jsonKpiDate.setActual(kpiData.getActual());
						jsonKpiDate.setDeviation(kpiData.getDeviated());
						jsonKpiDate.setExpected(kpiData.getExpected());
						jsonKpiDate.setType(kpiData.getType());
						if(kpi.getKpiData()==null) {
							List<JsonKpiDate> kpiDataList= new ArrayList<JsonKpiDate>();
							kpiDataList.add(jsonKpiDate);
							kpi.setKpiData(kpiDataList);
						}else {
							kpi.getKpiData().add(jsonKpiDate);		
						}
										
					}
				});
				if(block.getKpiList()==null) {
					List<JsonKpiModel> kpiList= new ArrayList<JsonKpiModel>();
					kpiList.add(kpi);
					block.setKpiList(kpiList);
				}else {
					block.getKpiList().add(kpi);	
				}
				
			});
			
		});
		//System.out.println(jsonDataModels);
		//System.out.println("kinnera");
		return jsonDataModels;
		
	}
}
