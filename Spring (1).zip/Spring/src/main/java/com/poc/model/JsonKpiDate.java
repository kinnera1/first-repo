package com.poc.model;

public class JsonKpiDate {
	Integer id;
	String type;
	String actual;
	String expected;
	String deviation;
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getActual() {
		return actual;
	}
	public void setActual(String actual) {
		this.actual = actual;
	}
	public String getExpected() {
		return expected;
	}
	public void setExpected(String expected) {
		this.expected = expected;
	}
	public String getDeviation() {
		return deviation;
	}
	public void setDeviation(String deviation) {
		this.deviation = deviation;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	

}
