package com.poc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PocSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(PocSpringBootApplication.class, args);
	}

}
