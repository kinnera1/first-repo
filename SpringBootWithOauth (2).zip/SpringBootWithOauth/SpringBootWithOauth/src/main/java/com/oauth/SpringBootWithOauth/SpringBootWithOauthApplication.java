package com.oauth.SpringBootWithOauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWithOauthApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWithOauthApplication.class, args);
	}

}
