import { Directive, HostBinding, OnInit, ElementRef } from '@angular/core';

@Directive({
  selector: '[appStatus]'
})
export class StatusDirective implements OnInit{
  @HostBinding('style.color') color: string;
  constructor(private elRef:ElementRef) { }

ngOnInit(){
  this.elRef.nativeElement.style.backgroundColor="green";
  //console.log(this.elRef.nativeElement.)
  //console.log(P);
}
}
