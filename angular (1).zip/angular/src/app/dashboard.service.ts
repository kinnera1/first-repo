import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  baseUrl:string = "http://localhost:8080/poc/blocks";

    constructor(private httpClient : HttpClient) {}

    get_blocks(){
        return this.httpClient.get(this.baseUrl);
    }
    
    }