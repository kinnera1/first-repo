export class Block{
    public id:number;
    public block_name:String;
    public status: string; 
    public kpiList:{
            id:number;
            kpi_name:String, 
            units: String, 
            kpiData:{
                id:number;
                type:String,
                actual:string,
                expected:string,
                deviation:string
            }[]
        }[];
   
}