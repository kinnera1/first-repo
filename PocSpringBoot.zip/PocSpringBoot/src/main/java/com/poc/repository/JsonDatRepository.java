package com.poc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.poc.model.JsonDataModel;

@Repository
public interface JsonDatRepository extends JpaRepository<JsonDataModel, String> {
//	@Query("select 	new com.poc.model.Block(a.block_name, a.status, b.kpi_name, b.units, c.type, c.actual, c.expected, c.deviated, a.id, b.id, c.id) " + 
//			"from 	JsonDataModel as a ,JsonKpiModel as b,JsonKpiDataModel as c " + 
//			"where 	b.id = c.jsonKpiModel and a.id = c.jsonDataModel " + 
//			"group by a.block_name, a.status, b.kpi_name, b.units, c.type, c.actual, c.expected, c.deviated")
//	public List<Block> getBlocks();

}
