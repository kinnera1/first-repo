package com.poc.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.poc.model.JsonKpiModel;

public interface JsonKpiRepository extends JpaRepository<JsonKpiModel, Integer> {

}
