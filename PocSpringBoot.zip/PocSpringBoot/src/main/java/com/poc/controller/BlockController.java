package com.poc.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.poc.model.Error;
import com.poc.model.JsonDataModel;
import com.poc.service.BlockService;

@RestController
public class BlockController {
	
	private static final Logger LOGGER = LogManager.getLogger(BlockController.class);
	
	@Autowired
	public BlockService blockServiceImpl;
	
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/blocks")
	public List<JsonDataModel> getBlocks(@RequestHeader("username") String username, @RequestHeader("password") String password){
		LOGGER.info("/blocks(a get request)");
		if(username.equals("kinnera") && password.equals("password")) {
			LOGGER.info("Valid incoming username and password ");
			return blockServiceImpl.jsonData();
			
		} else {
			LOGGER.error("Inalid incoming username and password! Username: "+ username);
			return new ArrayList<JsonDataModel>();
		}
		
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/errors")
	public void postErrors(@RequestBody String errorMessage, @RequestHeader("errorType") String errorType){
		//System.out.println(errorMessage);
		//System.out.println("Post errors to Database. errorType: " + error.getErrorType()+ ",ErrorMessage :" +error.getMessage());
		switch(errorType) {
		case "1": 
			LOGGER.debug(errorMessage);
			break;
		case "2": 
			LOGGER.info(errorMessage);
			break;
		case "3": 
			LOGGER.warn(errorMessage);
			break;
		case "4": 
			LOGGER.error(errorMessage);
			break;
		case "5": 
			LOGGER.fatal(errorMessage);
			break;
				
		}
		
	}

}
