package com.poc.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="jsonKpiData")
public class JsonKpiDataModel {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
	private String type;
	private String actual;
	private String expected;
	private String deviated;
	@ManyToOne
	JsonKpiModel jsonKpiModel;
	
	@ManyToOne
	JsonDataModel jsonDataModel;
	
	public Integer getId() {
		return id;
	}
	
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public JsonKpiModel getJsonKpiModel() {
		return jsonKpiModel;
	}

	public void setJsonKpiModel(JsonKpiModel jsonKpiModel) {
		this.jsonKpiModel = jsonKpiModel;
	}

	public JsonDataModel getJsonDataModel() {
		return jsonDataModel;
	}

	public void setJsonDataModel(JsonDataModel jsonDataModel) {
		this.jsonDataModel = jsonDataModel;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	public String getActual() {
		return actual;
	}
	public void setActual(String actual) {
		this.actual = actual;
	}
	public String getExpected() {
		return expected;
	}
	public void setExpected(String expected) {
		this.expected = expected;
	}
	public String getDeviated() {
		return deviated;
	}
	public void setDeviated(String deviated) {
		this.deviated = deviated;
	}
	
}
