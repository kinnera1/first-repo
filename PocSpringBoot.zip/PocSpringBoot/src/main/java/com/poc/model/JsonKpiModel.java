package com.poc.model;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="JsonKpis")
public class JsonKpiModel {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Integer id;
    private String kpi_name;
	private String units;
	@Transient
	List<JsonKpiDate> kpiData;
	public String getKpi_name() {
		return kpi_name;
	}
	public void setKpi_name(String kpi_name) {
		this.kpi_name = kpi_name;
	}
	public String getUnits() {
		return units;
	}
	public void setUnits(String units) {
		this.units = units;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public List<JsonKpiDate> getKpiData() {
		return kpiData;
	}
	public void setKpiData(List<JsonKpiDate> kpiData) {
		this.kpiData = kpiData;
	}
	
	
}
