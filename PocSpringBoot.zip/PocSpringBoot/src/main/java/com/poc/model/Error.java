package com.poc.model;

public class Error {
	private String errorMessage;
	private int errorType;
	
	public Error() {
		// TODO Auto-generated constructor stub
	}
	
	public Error(String errorMessage, int errorType) {
		super();
		this.errorMessage = errorMessage;
		this.errorType = errorType;
	}
	public int getErrorType() {
		return errorType;
	}
	public void setErrorType(int errorType) {
		this.errorType = errorType;
	}
	public String getMessage() {
		return errorMessage;
	}
	public void setMessage(String message) {
		this.errorMessage = message;
	}
	@Override
	public String toString() {
		return "Error [errorMessage=" + errorMessage + ", errorType=" + errorType + "]";
	}
	
	
}
