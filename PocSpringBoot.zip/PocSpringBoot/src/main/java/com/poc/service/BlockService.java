package com.poc.service;

import java.util.List;

import com.poc.model.JsonDataModel;

public interface BlockService {
	
	public List<JsonDataModel> jsonData();
}
