package com.poc.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.poc.model.JsonDataModel;
import com.poc.model.JsonKpiDataModel;
import com.poc.model.JsonKpiDate;
import com.poc.model.JsonKpiModel;
import com.poc.repository.JsoKpiDataRepository;
//import com.poc.repository.BlockRepository;
import com.poc.repository.JsonDatRepository;
import com.poc.repository.JsonKpiRepository;

@Service
@Transactional
public class BlockServiceImpl implements BlockService {

	private static final Logger LOGGER = LogManager.getLogger(BlockServiceImpl.class);
	
	@Autowired
	private JsonDatRepository jsonDatRepository;
	
	@Autowired
	private JsonKpiRepository jsonKpiRepository;

	@Autowired
	private JsoKpiDataRepository jsoKpiDataRepository ;
	
	public List<JsonDataModel> jsonData() {
		//System.out.println(jsonDatRepository.getBlocks());
		LOGGER.info("jsonData() - start: " + new Date() );
		List<JsonDataModel> jsonDataModels=jsonDatRepository.findAll();
		//System.out.println(jsonDataModels);
		List<JsonKpiModel> jsonKpiModels=jsonKpiRepository.findAll();

		List<JsonKpiDataModel> jsonKpiDataModels=jsoKpiDataRepository.findAll();
		//System.out.println(jsonKpiModels);
		//System.out.println(jsonKpiDataModels);
		jsonDataModels.forEach(block -> {
			
			jsonKpiModels.forEach(kpi ->{
				JsonKpiModel jsonKpiModel=new JsonKpiModel();
				jsonKpiDataModels.forEach(kpiData ->{
					if(block.getId()==kpiData.getJsonDataModel().getId() && 
							kpi.getId()==kpiData.getJsonKpiModel().getId()) {
						jsonKpiModel.setId(kpiData.getJsonKpiModel().getId());
						jsonKpiModel.setKpi_name(kpiData.getJsonKpiModel().getKpi_name());
						//System.out.println(kpiData.getJsonKpiModel().getKpi_name());
						jsonKpiModel.setUnits(kpi.getUnits());
						JsonKpiDate jsonKpiDate=new JsonKpiDate();
						jsonKpiDate.setId(kpiData.getId());
						jsonKpiDate.setActual(kpiData.getActual());
						jsonKpiDate.setDeviation(kpiData.getDeviated());
						jsonKpiDate.setExpected(kpiData.getExpected());
						jsonKpiDate.setType(kpiData.getType());
						if(jsonKpiModel.getKpiData()==null) {
							List<JsonKpiDate> kpiDataList= new ArrayList<JsonKpiDate>();
							kpiDataList.add(jsonKpiDate);
							jsonKpiModel.setKpiData(kpiDataList);
						}else {
							jsonKpiModel.getKpiData().add(jsonKpiDate);		
						}
						
										
					}
				});
				if(jsonKpiModel.getId()!=null) {
				if(block.getKpiList()==null) {
					List<JsonKpiModel> kpiList= new ArrayList<JsonKpiModel>();
					kpiList.add(jsonKpiModel);
					block.setKpiList(kpiList);
				}else {
					block.getKpiList().add(jsonKpiModel);	
				}}
				
			});
			//System.out.println(block.getKpiList().get(0).getKpi_name());
		});
		LOGGER.info("jsonData() - end: " + new Date() );
		return jsonDataModels;
		
	}
}
